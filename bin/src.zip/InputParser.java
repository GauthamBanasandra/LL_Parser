import java.util.List;

public class InputParser {
	public static Grammar parseInput(List<String> input) {
		Grammar g = new Grammar();
		for (String line : input) {
			String fs[] = line.split(">");
			NonTerminal head = new NonTerminal(fs[0]);
			if ()
		}
		return g;
	}
}
