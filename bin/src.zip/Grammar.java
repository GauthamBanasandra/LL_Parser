import java.util.ArrayList;
import java.util.List;


public class Grammar {
	final List<NonTerminal> nonTerminals = new ArrayList<>();
	final List<Terminal> terminals = new ArrayList<>();
}
