
public class Terminal extends Symbol {
	public Terminal(String v) {
		super(v);
	}
}
