
public abstract class Symbol {
	final String val;
	public Symbol(String val) {
		this.val = val;
	}
	
	@Override
	public boolean equals(Object obj) {
		return ((Symbol)obj).val == val;
	}
}
